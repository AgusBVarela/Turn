package com.example.demo.entities;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="pacients")

public class Pacient {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String name;
    private String lastName;
    private String address;
    private int dni;
    private LocalDate birthDate;
    private String phone;
    private String mail;
}
