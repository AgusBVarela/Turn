package com.example.demo.controllers;

import org.springframework.web.bind.annotation.*;

@RestController
public class TurnController {

    @GetMapping()
    public void getAll(){

    }

    @PostMapping()
    public void setTurn(){

    }

    @PutMapping()
    public void updateTurn(){

    }

    @DeleteMapping()
    public void deleteTurn(){

    }

}
