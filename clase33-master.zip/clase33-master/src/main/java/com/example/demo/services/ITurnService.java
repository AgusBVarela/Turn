package com.example.demo.services;

public interface ITurnService {
}
