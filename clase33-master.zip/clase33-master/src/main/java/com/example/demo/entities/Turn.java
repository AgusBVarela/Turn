package com.example.demo.entities;

import javax.persistence.*;

@Entity
@Table(name="turns")

public class Turn {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @ManyToOne
    @JoinColumn(name="id")
    private Diary diary;

    @OneToOne
    @JoinColumn(name="id")
    private TurnStatus turnStatus;

    @ManyToOne
    @JoinColumn(name="id")
    private Pacient pacient;
}
